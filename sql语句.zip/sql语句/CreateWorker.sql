create table WORKER
(
  WORKERID number  PRIMARY KEY,
  WORKER_NAME varchar2(50) not null,
  WORK_GENDER varchar2(50),
  WORKWE_AGE   NUMBER,
  WORKPWD       VARCHAR2(128) 
);
SELECT * FROM WORKER;
INSERT INTO WORKER VALUES (001,'����','��',23,'123456');
