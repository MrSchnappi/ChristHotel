create user Chao 
  identified by "123456"  
  default tablespace USERS  
  temporary tablespace TEMP  
  profile DEFAULT  
  password expire;  
-- Grant/Revoke role privileges   
grant connect to Chao;  
grant dba to Chao;  
grant resource to Chao;  
-- Grant/Revoke system privileges   
grant create any view to Chao;  
grant unlimited tablespace to Chao; 
